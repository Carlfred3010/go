package math

type Float64Calculator struct{}
